# Hoodochi — générateur

Prérequis : `pip install pillow numpy`

- `creature.py`   : créature de base + traits de naissance (corps, yeux, antennes, fonds unis)
- `items2.py`     : les 20 items (5 slots × 4 paliers) + `build(body, eyes, tip, ticker, equip, bg)` = fonction de rendu
- `rare_bg.py`    : les 10 fonds rares
- `gen_collection.py` : génère `collection/` (1 000 images + metadata + collection.json avec provenance)

Rendu à la demande (serveur) : appeler `items2.build(...)` avec l'état du token, puis `.resize((768,768), NEAREST)`.

Après upload des images sur IPFS : remplacer `IMAGE_BASE` dans gen_collection.py et relancer,
ou faire un sed sur `collection/metadata/*`.
